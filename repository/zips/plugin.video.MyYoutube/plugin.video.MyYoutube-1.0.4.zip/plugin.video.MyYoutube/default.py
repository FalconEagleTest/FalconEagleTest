# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,json,threading

Addon = xbmcaddon.Addon(id='plugin.video.MyYoutube')
addonPath = xbmc.translatePath(Addon.getAddonInfo("path")).decode("utf-8")

__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'

import socket

socket.setdefaulttimeout(30.0)
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     

###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description)
  
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        return ok


def addLink( name, url,mode,isFolder, iconimage,description):
 

          
         
         
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title":  name, "Plot": description   })
          liz.setProperty( "Fanart_Image", iconimage )
          liz.setProperty("IsPlayable","true")
          
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
def read_site_html(url):
    import requests

    cookies = {
        'PREF': 'HIDDEN_MASTHEAD_ID=wo5p019sJqo&f5=30&al=iw&f1=50000000',
        'VISITOR_INFO1_LIVE': 'gAV32V2Yoj8',
        'CONSENT': 'YES+DE.iw+V8',
        '_ga': 'GA1.2.1102943109.1491329246',
        'SID': 'dwUD0z1Qek9KRby-x5XPgGDzQVG-F22gAWRG-hIZ0T85iPLxHTZ1qeV7Kr9HAIecMfmbUw.',
        'HSID': 'AHjPEdvJ_szjJ5F2Z',
        'SSID': 'ASgUq0eqtQ0f_-MKn',
        'APISID': '3FDXL0Fkpx4JsALg/ADDeScfwowfIywKQ-',
        'SAPISID': 'ngB1aCu7aYw_K80J/AbvIGXHBVhRKkBkEB',
        'LOGIN_INFO': 'ACn9GHowRQIhAOJM7W72jweA43hTqrmGr838IybkLYvnhyBxe14lKurkAiAIkD_J906auUMSZBMOtsow__mxSrq8DeL7IHhyb33DIQ:QUxJMndvSEU5akJPZnd2ZmE3dWgtVW9Tbl9QRUNXMTNfWGJlUTNRaFFzYUtfNXlPeEtTcHJOb0piY0Z1NjllVUNEQm5tU1JHSm9YY0dIYXJ6cm41Z0NMTmtZZVpCRi1sUk1jamhLU3VzTlR0dWZxM1doU3pyZEhUdzBJcnhfQi1McVZqTE5lTEFaTGNYOC1JdU8yM2djQWVnblhZc0xVSGxBbVNhd2tYTXdBd2lRMjl2eUJMaW0w',
        'YSC': 'K7YgNPoPQDY',
        's_gl': 'd51766b086658500406c2f99316de348cwIAAABJTA==',
    }

    headers = {
        'Host': 'www.youtube.com',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
    }
 
    x=requests.get(url, headers=headers).text
    if 'ytInitialData' not in x:
      x=requests.get(url, headers=headers).text
    return x.encode('utf8')

def read_site_html2(url_link):

    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    return html

def loging( username, password):
        import requests

        cookies = {
            'NID': '118=X_rd_skzDu7r0vBbTXkmkYeooZf20zDBLiT0Dib8yMvV632ROhgq1GmNxWBjxUzYBC5-V4mSASTaDlnWcqP9RFUt0uMcF2buEqNWX6V2dwYgLdWdCLcPGkz4Dy4e3NBKO3XWaPVhy3K9Wwz72PqGmkpNbZvg8kgq1K79GymG5wZXUHFsowjsF8E3iJG_UFhtKP9H6LVNb2p6ZOHtmnVuA2vOzD0',
            'GAPS': '1:FzWC06Vp3BHirGWgrGnzrVP_NSrRM76_YD556ZuA2q-ryWBAYif6_s7y5zUj6GndQtIbPRDFtA_-9PIR7p3ZdkmGN5l5TFAM7dRIfCtRfGDgNA:FS4yPld1qYrTpnot',
            'ACCOUNT_CHOOSER': 'AFx_qI5WK24G2Cnl6jlPhuowVElzGCdFlFWjc14ymgDhR7e0F8an-q0RrpsmfCnNHV4_qY2_oviNWiJVQRbnncisNUdKVQZeUDF2w8vsTWDPeoAxcjOKRzbftTjdJm0N0zM1OIJ-LkJho5qc6zXFbQ7tMLS-0nXFO4xfi2G2H19AVYKqoTOLdc7nWO6QyFsHV-3qCaxsJv_NA1n5wb-aQ1FEO3WAnMCZ_BGJ2uxHTrH14jWHeKig5MZowT2kGQ1lbWfZm4t0KKCXziReAsII1bxDJOqvWuRqU0sVwE7wYPaKJ81HjHSmGUnSeELRO7vQ64-N4Mkhs7Qp3m0zXPjwC6cIw8IfPmA35WZpCpM7BPfTL0JJTiatJMhv8e6HJRiWf3krLS1NPPMi',
            'CONSENT': 'YES+DE.iw+V8',
            '__utma': '72592003.1386208110.1498569697.1498569697.1498569697.1',
            '__utmz': '72592003.1498569697.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none)',
            'OGPC': '5061821-25:5061451-9:873035776-1:',
            '1P_JAR': '2017-12-4-6',
            'OGP': '-5061451:-873035776:',
            'expor': '3100077',
            'GEM': 'CgptaW51dGVtYWlkEOTgv-uBLA==',
            'OCAK': 'utg2t2tEHqv4Su_IdkLwukQPGZ_CRVJc_QlaYpkz-YU',
        }

        headers = {
            'Host': 'accounts.google.com',
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:57.0) Gecko/20100101 Firefox/57.0',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'he,he-IL;q=0.8,en-US;q=0.5,en;q=0.3',
            'Referer': 'https://accounts.google.com/signin/v2/sl/pwd?service=youtube&uilel=3&continue=https%3A%2F%2Fwww.youtube.com%2Fsignin%3Fhl%3Den%26action_handle_signin%3Dtrue%26next%3D%252Fresults%253Fsearch_query%253Dshort%252Bplaylist%26app%3Ddesktop&passive=true&flowName=GlifWebSignIn&flowEntry=AddSession&cid=0&navigationDirection=forward',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
            'Pragma': 'no-cache',
            'Cache-Control': 'no-cache',
        }

        data = [
          ('continue', 'https://www.youtube.com/signin?hl=en&action_handle_signin=true&next=%2Fresults%3Fsearch_query%3Dshort%2Bplaylist&app=desktop'),
          ('identifier', username),
          ('password', password),
          ('ca', ''),
          ('ct', ''),
        ]

        x=requests.post('https://accounts.google.com/signin/v2/challenge/password/empty', headers=headers,cookies=cookies, data=data)
        logging.warning(x)


def pop_youtube_data(name,url):


    html=read_site_html(url)

    regex='"ytInitialData".+?= (.+?)};'
    match=re.compile(regex,re.DOTALL).findall(html)

    json_data=json.loads(match[0]+'}')
    
    for value in json_data['contents']['twoColumnBrowseResultsRenderer']['tabs'][0]['tabRenderer']['content']['sectionListRenderer']['contents']:
       if 'expandedShelfContentsRenderer' in value['itemSectionRenderer']['contents'][0]['shelfRenderer']['content']:
          new_key='expandedShelfContentsRenderer'
       else:
         new_key='horizontalListRenderer'
       for val in value['itemSectionRenderer']['contents'][0]['shelfRenderer']['content'][new_key]['items']:
         if 'gridRadioRenderer' in val:
             if 'playlistId' in val['gridRadioRenderer']:
               
               playid='playid@@@@'+val['gridRadioRenderer']['playlistId']
             else:
               playid='videoid@@@@'+val['gridRadioRenderer']['videoId']
             
             image=val['gridRadioRenderer']['thumbnail']['thumbnails'][0]['url']
             name=val['gridRadioRenderer']['title']['simpleText']
             if 'videoCountText' in val['gridRadioRenderer']:
               plot=val['gridRadioRenderer']['videoCountText']['runs'][0]['text']
             else:
               plot=" "
         elif 'gridVideoRenderer' in val:
             if 'playlistId' in val['gridVideoRenderer']:
               
               playid='playid@@@@'+val['gridVideoRenderer']['playlistId']
             else:
               playid='videoid@@@@'+val['gridVideoRenderer']['videoId']
             
             image=val['gridVideoRenderer']['thumbnail']['thumbnails'][0]['url']
             name=val['gridVideoRenderer']['title']['simpleText']
             if 'videoCountText' in val['gridVideoRenderer']:
               plot=val['gridVideoRenderer']['videoCountText']['runs'][0]['text']
             else:
               plot=" "
         elif 'videoRenderer' in val:
             if 'playlistId' in val['videoRenderer']:
               
               playid='playid@@@@'+val['videoRenderer']['playlistId']
             else:
               playid='videoid@@@@'+val['videoRenderer']['videoId']
               
             
             image=val['videoRenderer']['thumbnail']['thumbnails'][0]['url']
             name=val['videoRenderer']['title']['simpleText']
             if 'videoCountText' in val['videoRenderer']:
               plot=val['videoRenderer']['videoCountText']['runs'][0]['text']
             else:
               plot=" "
         addLink( name, playid,3,False, image,plot)
    '''
    if 'page=' in url:
      next_page=url.split('page=')
      next=next_page[0]+'page='+str(int(next_page)+1)
    else:
      next=url+'&page='+str(2)
    addDir3('[COLOR aqua][I][B]העמוד הבא[/B][/I][/COLOR]',next,2,'','','עמוד הבא')
    '''
def main_menu():
    check_youtuedl()
    html=read_site_html('https://www.youtube.com/')
    
  
    regex='var ytInitialGuideData = (.+?);'
    match=re.compile(regex,re.DOTALL).findall(html)
    json_data=json.loads(match[0])
    for val in json_data['items']:
     if 'guideSectionRenderer' in val :
      
          for value in val['guideSectionRenderer']['items']:
            if  'navigationEndpoint' in value['guideEntryRenderer']:
                name=value['guideEntryRenderer']['title']
                link='https://www.youtube.com/'+value['guideEntryRenderer']['navigationEndpoint']['webNavigationEndpointData']['url']
                
                if "הגדרות".decode('utf8') not in name   and "ערוצים".decode('utf8') not in  name and "היסטוריית".decode('utf8') not in  name :
                  addDir3(name,link,2,'','',name)
    addDir3('חיפוש','www',4,'','','חיפוש')



def get_directlink(url):

     import YDStreamExtractor
     vid = YDStreamExtractor.getVideoInfo(url,quality=2,resolve_redirects=True) #quality is 0=SD, 1=720p, 2=1080p and is a maximum

     if vid==None:
      return 'NONE'
     stream_url = vid.streamURL() #This is what Kodi (XBMC) will play
     
     return stream_url
def populate (url,playlist,x):
         import YDStreamExtractor
         link= YDStreamExtractor.getVideoInfo(url,quality=2)
       
         

         stream_url = link.streamURL()
         listitem =xbmcgui.ListItem (name, thumbnailImage=' ')
         listitem.setInfo('video', {'Title': name})
         playlist.add(url=stream_url, listitem=listitem, index=x)

  
         
def play_video(name,url):
    
    id=url.split("@@@@")[1]

    if '/watch?v=' not in id:
     id='/watch?v='+id
    
    link=get_directlink('https://www.youtube.com/'+id)
    listItem = xbmcgui.ListItem(name, path=link) 
    listItem.setInfo(type='Video', infoLabels={"Title": name})
    xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)

    if url.split("@@@@")[0]=="playlistId":
       html=read_site_html('https://www.youtube.com/'+url.split("@@@@")[1])

       
       regex='"ytInitialData".+?= (.+?)};'
       match=re.compile(regex,re.DOTALL).findall(html)

       json_data=json.loads(match[0]+'}')
       
       playlist =xbmc.PlayList (xbmc.PLAYLIST_VIDEO)
       playlist.clear()
       x=0
       for value in json_data['contents']['twoColumnWatchNextResults']['playlist']['playlist']['contents']:
         link_b=value['playlistPanelVideoRenderer']['navigationEndpoint']['webNavigationEndpointData']['url']
         name=value['playlistPanelVideoRenderer']['title']['simpleText']
         threading.Thread(target=populate, args=('https://www.youtube.com/'+link_b,playlist,x )).start()
         x=x+1

    


       

def search_results(name,url):

    if 'חיפוש' in name and "העמוד" not in name:
        search_entered =''
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
                    search_entered = keyboard.getText()
        
        if search_entered !='' :
          url='https://www.youtube.com/results?search_query='+search_entered.replace(' ','+')

    html=read_site_html(url)
  
    regex='"ytInitialData".+?= (.+?)};'
    match=re.compile(regex,re.DOTALL).findall(html)
   

    json_data=json.loads(match[0]+'}')
 

    for value in json_data['contents']['twoColumnSearchResultsRenderer']['primaryContents']['sectionListRenderer']['contents'][0]['itemSectionRenderer']['contents']:
       #logging.warning(value)
       if 'videoRenderer' in value:
         link='videoid@@@@'+value['videoRenderer']['navigationEndpoint']['webNavigationEndpointData']['url']
         name=value['videoRenderer']['title']['simpleText']
         image=value['videoRenderer']['thumbnail']['thumbnails'][0]['url']
         plot=value['videoRenderer']['title']['accessibility']['accessibilityData']['label']
         addLink( name, link,3,False, image,plot)
       elif 'radioRenderer' in value :
         link='playlistId@@@@'+value['radioRenderer']['navigationEndpoint']['webNavigationEndpointData']['url']
         name=value['radioRenderer']['title']['simpleText'] 
         image=value['radioRenderer']['thumbnail']['thumbnails'][0]['url']
         plot=value['radioRenderer']['videoCountText']['runs'][0]['text']
         addLink( name, link,3,False, image,plot)
       elif 'playlistRenderer' in value :
         link='playlistId@@@@'+value['playlistRenderer']['navigationEndpoint']['webNavigationEndpointData']['url']
         name=value['playlistRenderer']['title']['simpleText'] 
         image=value['playlistRenderer']['thumbnails'][0]['thumbnails'][0]['url']
         plot=value['playlistRenderer']['videoCountText']['runs'][0]['text']
         addLink( name, link,3,False, image,plot)
    
    if 'page=' in url:
      next_page=url.split('page=')
      next=next_page[0]+'page='+str(int(next_page[1])+1)
    else:
      next=url+'&page='+str(2)
    addDir3('[COLOR aqua][I][B]העמוד הבא[/B][/I][/COLOR]',next,4,'','','עמוד הבא')
def check_youtuedl():
   from shutil import copyfile
   you_Addon = xbmcaddon.Addon(id='script.module.youtube.dl')
   you_addonPath = xbmc.translatePath(you_Addon.getAddonInfo("path")).decode("utf-8")
   libDir = os.path.join(you_addonPath,  'lib','YoutubeDLWrapper.py')

   file = open(libDir,'r').read()
   if '#if xbmc.abortRequested:' not in file:
    libDir2 = os.path.join(addonPath,'YoutubeDLWrapper.py')
    copyfile(libDir2, libDir)


params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
   


if url is not None:
  url=url.replace("@@@@@@","=").replace("*****","&").replace("!!!!!!","?")  

if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==2:
     pop_youtube_data(name,url)
elif mode==3:
     play_video(name,url)
elif mode==4:
     search_results(name,url)
xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
xbmc.executebuiltin("Container.SetViewMode(504)")

xbmcplugin.endOfDirectory(int(sys.argv[1]))

